import { Component, OnInit } from '@angular/core';
import { ProductsListService } from '../products-list.service';
import { ProductList } from '../ProductList';
import { ActivatedRoute } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.css']
})
export class ProductsListComponent implements OnInit {
  uname: string;
  constructor(private servics: ProductsListService, private route: ActivatedRoute) {
    route.params.subscribe(params => this.uname = params['uname']);
  }
  proList: ProductList[];
  ngOnInit() {
    this.getAllProducts();
  }
  getAllProducts() {
    this.servics.getAllProducts().subscribe(Data => this.proList = Data);
  }
}
