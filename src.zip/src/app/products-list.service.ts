
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProductList } from './ProductList';
import { Observable } from '../../node_modules/rxjs';
@Injectable({
  providedIn: 'root'
})
export class ProductsListService {

  constructor(private http: HttpClient) { }
url:string = '/assets/Data/productList.json';
getAllProducts():Observable<ProductList[]>
{
     return this.http.get<ProductList[]>(this.url);
}


}

