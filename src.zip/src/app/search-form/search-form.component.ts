import { Component, OnInit } from '@angular/core';
import { ProductsListService } from '../products-list.service';
import { ProductList } from '../ProductList';
@Component({
  selector: 'app-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.css']
})
export class SearchFormComponent implements OnInit {
  constructor(private servics: ProductsListService) { }
  proList:ProductList[];
searchList:ProductList[];

  ngOnInit(){
    this.getAllProducts();
  }
  getAllProducts()
  {
    this.servics.getAllProducts().subscribe(Data => this.proList = Data);
  }
  search(myForm)
  {
    //console.log(this.proList.length);
    for(let i = 0; i < this.proList.length; i++)
    {
      let j=0;
      this.searchList=[];
      //console.log(i);
      //console.log(this.proList[i].name);
      //console.log(myForm.value.name);

      if(this.proList[i].name==myForm.value.name)
      {
       // console.log("hello");
        this.searchList[j]=this.proList[i];
        //console.log(this.searchList[j])

      }

    }

  }
}
